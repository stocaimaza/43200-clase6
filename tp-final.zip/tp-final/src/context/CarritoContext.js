//1) Voy a importar el Hook useState y createContext que me permite crear un contexto que va a almacenar toda la lógica de mi carrillo de compras. 

import { useState, createContext } from "react";

//2) Creamos un nuevo contexto. 
//El valor inicial por default es un objeto con la propiedad "carrito" con un array vacío. 

export const CarritoContext = createContext({ carrito: [] });

//Creamos el componente "CarritoProvider". También lo pueden encontrar como proveedor de contextos. 
export const CarritoProvider = ({ children }) => {
    //3) Creamos un estado local "carrito" con el hook useState.
    const [carrito, setCarrito] = useState([]);

    //Verificamos por consola: 
    console.log(carrito);


    //4) Agregamos algunos métodos al proveedor para manipular el carrito de compras: 

    //Función para agregar productos al carrito: 
    const agregarProducto = (item, cantidad) => {
        // Verificamos si el producto ya está en el carrito
        const productoExistente = carrito.find(prod => prod.item.id === item.id);

        if (!productoExistente) {
            // Si el producto no existe, lo agregamos al carrito
            setCarrito(prev => [...prev, { item, cantidad }]);
        } else {
            // Si el producto ya existe, actualizamos su cantidad
            const carritoActualizado = carrito.map(prod => {
                if (prod.item.id === item.id) {
                    return { ...prod, cantidad: prod.cantidad + cantidad };
                } else {
                    return prod;
                }
            });

            setCarrito(carritoActualizado);
        }
    }

    /*
    //Función auxiliar "yaEstaEnCarrito":
    const yaEstaEnCarrito = (id) => {
        return carrito.some(prod => prod.id === id);
    }
    */

    //Función para eliminar productos del carrito: 

    const eliminarProducto = (id) => {
        const carritoActualizado = carrito.filter(prod => prod.id !== id);
        setCarrito(carritoActualizado);
    }

    //Función para vaciar el carrito de compras: 
    const vaciarCarrito = () => {
        setCarrito([]);
    }

    //5)Usamos el componente CarritoContext.Provider para enviar el valor actual del carrito y los métodos a los componentes de mi aplicación que lo necesiten.

    return (
        <CarritoContext.Provider value={{ carrito, agregarProducto, eliminarProducto, vaciarCarrito }} >
            {children}
        </CarritoContext.Provider>

    )

    //6) Children: propiedad especial que se utiliza para representar a todos aquellos componentes que puedan necesitar el carrito y sus métodos. 

}